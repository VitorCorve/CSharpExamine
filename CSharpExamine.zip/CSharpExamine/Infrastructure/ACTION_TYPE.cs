﻿namespace CSharpExamine.Infrastructure
{
    public enum ACTION_TYPE
    {
        Create,
        Edit,
        Delete
    }
}

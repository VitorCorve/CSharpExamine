﻿using System;
using System.Collections.Generic;

namespace CSharpExamine.Models
{
    [Serializable]
    public class QuestionsXml
    {
        public List<Question> Questions { get; set; }
    }
}
